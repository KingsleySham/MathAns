import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { Server } from 'socket.io';
import { createServer } from 'http';

// We can type these if we shared them, but for now we'll just keep it simple
interface AppState {
  mode: 'landing' | 'info' | 'settings' | 'lucky_draw' | 'bracket';
  settings: {
    advanceCount: number;
    openLanes: number;
    participants: number[];
  };
  drawOrder: number[];
  rounds: {
    title?: string;
    matches: {
      id: string;
      participants: number[];
      scores: Record<number, number>;
      finished: boolean;
    }[];
  }[];
  lastUpdated: number;
}

const INITIAL_STATE: AppState = {
  mode: 'landing',
  settings: {
    advanceCount: 1,
    openLanes: 6,
    participants: [],
  },
  drawOrder: [],
  rounds: [],
  lastUpdated: Date.now(),
};

let currentState: AppState = { ...INITIAL_STATE };

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  const PORT = 3000;

  // Basic API to verify health
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  app.post('/api/reset', (req, res) => {
    currentState = {
      ...INITIAL_STATE,
      settings: { ...INITIAL_STATE.settings, participants: [] },
      drawOrder: [],
      lastUpdated: Date.now()
    };
    io.emit('stateUpdated', currentState);
    res.json({ success: true });
  });

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Send immediate initial sync
    socket.emit('stateUpdated', currentState);

    socket.on('updateState', (partialState: Partial<AppState>) => {
      currentState = {
        ...currentState,
        ...partialState,
        lastUpdated: Date.now()
      };
      // Broadcast to everybody including sender so they reconcile easily
      io.emit('stateUpdated', currentState);
    });

    socket.on('updateScore', ({ matchId, studentId, score }: { matchId: string, studentId: number, score: number }) => {
      // Find the match in rounds
      for (const round of currentState.rounds) {
        const match = round.matches.find(m => m.id === matchId);
        if (match) {
          if (!match.scores) match.scores = {};
          match.scores[studentId] = score;
          currentState.lastUpdated = Date.now();
          io.emit('stateUpdated', currentState);
          return;
        }
      }
    });

    socket.on('toggleMatchFinished', ({ matchId, finished }: { matchId: string, finished: boolean }) => {
      for (const round of currentState.rounds) {
        const match = round.matches.find(m => m.id === matchId);
        if (match) {
          match.finished = finished;
          currentState.lastUpdated = Date.now();
          io.emit('stateUpdated', currentState);
          return;
        }
      }
    });

    socket.on('generateNextRound', () => {
      if (currentState.rounds.length === 0) {
        // Initial Round Generation based on drawOrder
        let participants = [...currentState.drawOrder];
        const totalMatches = currentState.settings.openLanes;
        
        const newMatches = [];
        const baseSize = Math.floor(participants.length / totalMatches);
        const extra = participants.length % totalMatches;
        
        let currentIndex = 0;
        for (let i = 0; i < totalMatches; i++) {
          const spotsForThisMatch = baseSize + (i < extra ? 1 : 0);
          const matchParticipants = [];
          for (let j = 0; j < spotsForThisMatch; j++) {
            matchParticipants.push(participants[currentIndex++]);
          }
          newMatches.push({
            id: `r1-m${i + 1}`,
            participants: matchParticipants,
            scores: {},
            finished: false
          });
        }
        
        let title = 'Round 1';
        if (totalMatches === 1) title = 'Finals';
        else if (totalMatches === 2) title = 'Semi-Finals';
        else if (totalMatches === 3 || totalMatches === 4) title = 'Quarter-Finals';
        
        currentState.rounds.push({ title, matches: newMatches });
        currentState.lastUpdated = Date.now();
        io.emit('stateUpdated', currentState);
      } else {
        // Generate next round from previous round's advanced players
        const lastRound = currentState.rounds[currentState.rounds.length - 1];
        const advancedPlayers: number[] = [];
        
        for (const match of lastRound.matches) {
          if (!match.finished) {
            // Cannot generate next round until previous is fully finished
            return;
          }
          // Sort participants by score descending
          const sorted = [...match.participants].sort((a, b) => {
            const scoreA = match.scores[a] || 0;
            const scoreB = match.scores[b] || 0;
            return scoreB - scoreA; // descending
          });
          
          const advancedFromMatch = sorted.slice(0, currentState.settings.advanceCount);
          advancedPlayers.push(...advancedFromMatch);
        }

        if (advancedPlayers.length <= 1) {
          // Tournament is over!
          return;
        }

        const roundNumber = currentState.rounds.length + 1;
        let pArray = [...advancedPlayers];
        
        // We want to make good use of the lanes while progressing towards a final
        let numMatches = Math.min(currentState.settings.openLanes, Math.floor(pArray.length / 2));
        
        // If 6 or fewer players remain, we put them all in the Finals on 1 lane to increase excitement
        if (pArray.length <= 6) {
          numMatches = 1;
        } else if (numMatches < 2) {
          numMatches = 1;
        }

        const newMatches = [];
        const baseSize = Math.floor(pArray.length / numMatches);
        const extra = pArray.length % numMatches;
        
        let currentIndex = 0;
        for (let i = 0; i < numMatches; i++) {
          const spotsForThisMatch = baseSize + (i < extra ? 1 : 0);
          const matchParticipants = [];
          for (let j = 0; j < spotsForThisMatch; j++) {
            matchParticipants.push(pArray[currentIndex++]);
          }
          newMatches.push({
            id: `r${roundNumber}-m${i + 1}`,
            participants: matchParticipants,
            scores: {},
            finished: false
          });
        }
        
        let title = `Round ${roundNumber}`;
        if (numMatches === 1) title = 'Finals';
        else if (numMatches === 2) title = 'Semi-Finals';
        else if (numMatches === 3 || numMatches === 4) title = 'Quarter-Finals';
        
        currentState.rounds.push({ title, matches: newMatches });
        currentState.lastUpdated = Date.now();
        io.emit('stateUpdated', currentState);
      }
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Since react router might be used or just SPA fallback
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
