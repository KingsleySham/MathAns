import { motion } from 'motion/react';
import { AppState, Student } from '../types';
import { ALL_STUDENTS } from '../constants';
import { Check, Settings, ArrowRight, Users, Hash, Trophy } from 'lucide-react';
import { useState } from 'react';

interface Props {
  state: AppState;
  updateState: (s: Partial<AppState>) => void;
}

export default function SettingsView({ state, updateState }: Props) {
  const [advanceCount, setAdvanceCount] = useState(state.settings.advanceCount || 1);
  const [openLanes, setOpenLanes] = useState(state.settings.openLanes || 6);
  const [participants, setParticipants] = useState<number[]>(
    state.settings.participants.length > 0 
      ? state.settings.participants 
      : ALL_STUDENTS.map(s => s.id)
  );

  const toggleStudent = (id: number) => {
    setParticipants(prev => 
      prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]
    );
  };

  const handleNext = () => {
    updateState({
      settings: { advanceCount, openLanes, participants },
      mode: 'lucky_draw',
      // Reset draw order and rounds if we re-configure
      drawOrder: [],
      rounds: []
    });
  };

  return (
    <div className="min-h-screen flex flex-col items-center py-16 px-4 bg-[#FDFBF7] text-gray-900 relative">
      <div className="absolute top-0 right-0 w-[40%] h-[40%] rounded-full bg-red-100 blur-[100px] pointer-events-none" />
      
      <div className="w-full max-w-5xl z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4 mb-8 border-b border-red-200 pb-6"
        >
          <div className="p-3 rounded-2xl bg-white border border-red-200 shadow-sm">
            <Settings className="text-red-500" size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight text-red-950">Tournament Setup</h1>
            <p className="text-red-900/60 font-medium">Configure match sizes and participants.</p>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="md:col-span-1 space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 }}
              className="p-6 rounded-3xl bg-white border border-red-100 shadow-sm"
            >
              <div className="flex items-center gap-3 mb-4">
                <Trophy className="text-orange-500" size={20} />
                <h2 className="text-lg font-bold text-gray-800">Advanced per Match</h2>
              </div>
              <div className="flex items-center gap-4 bg-[#FDFBF7] p-2 rounded-2xl border border-red-100">
                <button 
                  onClick={() => setAdvanceCount(Math.max(1, advanceCount - 1))}
                  className="w-12 h-12 flex items-center justify-center rounded-xl bg-white hover:bg-gray-50 border border-gray-200 transition font-bold text-xl text-red-600"
                >
                  -
                </button>
                <div className="flex-1 text-center text-3xl font-black text-gray-900">{advanceCount}</div>
                <button 
                  onClick={() => setAdvanceCount(Math.min(10, advanceCount + 1))}
                  className="w-12 h-12 flex items-center justify-center rounded-xl bg-white hover:bg-gray-50 border border-gray-200 transition font-bold text-xl text-red-600"
                >
                  +
                </button>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.18 }}
              className="p-6 rounded-3xl bg-white border border-red-100 shadow-sm"
            >
              <div className="flex items-center gap-3 mb-4">
                <Hash className="text-blue-500" size={20} />
                <h2 className="text-lg font-bold text-gray-800">Open Lanes</h2>
              </div>
              <div className="flex items-center gap-4 bg-[#FDFBF7] p-2 rounded-2xl border border-red-100">
                <button 
                  onClick={() => setOpenLanes(Math.max(1, openLanes - 1))}
                  className="w-12 h-12 flex items-center justify-center rounded-xl bg-white hover:bg-gray-50 border border-gray-200 transition font-bold text-xl text-red-600"
                >
                  -
                </button>
                <div className="flex-1 text-center text-3xl font-black text-gray-900">{openLanes}</div>
                <button 
                  onClick={() => setOpenLanes(openLanes + 1)}
                  className="w-12 h-12 flex items-center justify-center rounded-xl bg-white hover:bg-gray-50 border border-gray-200 transition font-bold text-xl text-red-600"
                >
                  +
                </button>
              </div>
            </motion.div>


            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="p-6 rounded-3xl bg-white border border-red-100 shadow-sm"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Users className="text-red-500" size={20} />
                  <h2 className="text-lg font-bold text-gray-800">Participants</h2>
                </div>
                <div className="px-3 py-1 bg-red-100 text-red-800 font-bold rounded-full text-sm">
                  {participants.length}
                </div>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => setParticipants(ALL_STUDENTS.map(s => s.id))}
                  className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-700 transition"
                >
                  Select All
                </button>
                <button 
                  onClick={() => setParticipants([])}
                  className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-red-50 hover:bg-red-100 text-red-700 transition"
                >
                  Clear All
                </button>
              </div>
            </motion.div>
            
            <motion.button
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              onClick={handleNext}
              disabled={participants.length === 0}
              className="w-full flex items-center justify-center gap-3 py-4 rounded-2xl bg-gradient-to-r from-red-600 to-orange-500 text-white font-bold text-lg shadow-lg shadow-red-500/25 disabled:opacity-50 disabled:grayscale transition hover:scale-[1.02]"
            >
              Proceed to Lucky Draw
              <ArrowRight size={20} strokeWidth={2.5}/>
            </motion.button>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="md:col-span-2 p-6 rounded-3xl bg-white border border-red-100 shadow-sm flex flex-col h-[600px]"
          >
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
              Student Roster
            </h2>
            <div className="flex-1 overflow-y-auto pr-2 space-y-2 select-none">
              {ALL_STUDENTS.map(student => {
                const isSelected = participants.includes(student.id);
                return (
                  <div 
                    key={student.id}
                    onClick={() => toggleStudent(student.id)}
                    className={`flex items-center p-3 rounded-xl cursor-pointer border transition-all ${
                      isSelected 
                        ? 'bg-red-50 border-red-200 text-red-950 shadow-sm' 
                        : 'bg-white border-gray-100 text-gray-500 hover:border-gray-300'
                    }`}
                  >
                    <div className={`w-6 h-6 mr-4 rounded-md flex items-center justify-center flex-shrink-0 transition-colors ${
                      isSelected ? 'bg-red-500 text-white shadow-inner' : 'bg-gray-100 border border-gray-200'
                    }`}>
                      {isSelected && <Check size={14} strokeWidth={3} />}
                    </div>
                    <div className="w-8 font-mono text-sm opacity-50 font-bold">{student.no}</div>
                    <div className={`flex-1 font-bold ${isSelected ? 'text-red-900' : 'text-gray-600'}`}>{student.name}</div>
                    <div className="text-sm font-medium border opacity-70 ml-2 px-2 py-1 rounded bg-[#FDFBF7] border-gray-200">{student.zhName}</div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
