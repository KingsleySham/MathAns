import { motion } from 'motion/react';
import { ArrowRight, Trophy, Clock, Trash2, Loader2, Calendar } from 'lucide-react';
import { useEffect, useState } from 'react';
import { AppState } from '../types';
import { auth, signInAnonymouslyUser } from '../lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { subscribeToRecords, deleteRecordFromFirebase, SavedRecord } from '../lib/records';
import { Link } from 'react-router-dom';

interface Props {
  onNext: () => void;
  updateState: (s: Partial<AppState>) => void;
}

export default function LandingView({ onNext, updateState }: Props) {
  const [savedRecords, setSavedRecords] = useState<SavedRecord[]>([]);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const unsubAuth = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const unsubRecords = subscribeToRecords((records) => {
          setSavedRecords(records);
        });
        return () => unsubRecords();
      } else {
        setUser(null);
        setSavedRecords([]);
        signInAnonymouslyUser();
      }
    });
    return () => unsubAuth();
  }, []);

  const deleteRecord = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await deleteRecordFromFirebase(id);
    } catch (e) {
      console.error(e);
    }
  };

  const loadRecord = (record: SavedRecord) => {
    updateState({
      mode: 'lucky_draw',
      settings: {
        advanceCount: 1, // Default or store it in record if needed
        openLanes: record.openLanes,
        participants: record.participants,
      },
      drawOrder: record.drawOrder,
      rounds: []
    });
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen overflow-x-hidden overflow-y-auto bg-[#FDFBF7] py-12">
      
      {/* Dynamic Background Gradients */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] rounded-full bg-red-400/20 blur-[120px]" />
        <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] rounded-full bg-orange-400/20 blur-[120px]" />
        <div className="absolute top-[20%] right-[10%] w-[40%] h-[40%] rounded-full bg-yellow-400/20 blur-[100px]" />
      </div>

      <motion.div 
        className="z-10 flex flex-col items-center text-center px-4 mb-16"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, ease: 'easeOut' }}
      >
        <motion.div
           initial={{ scale: 0.8, rotate: -10 }}
           animate={{ scale: 1, rotate: 0 }}
           transition={{ duration: 0.8, type: 'spring', bounce: 0.5 }}
           className="mb-8 p-6 rounded-3xl bg-white shadow-[0_20px_50px_rgba(239,68,68,0.2)]"
        >
          <Trophy size={80} strokeWidth={2} className="text-red-500 drop-shadow-sm" />
        </motion.div>

        <h1 className="text-6xl md:text-8xl font-black mb-4 tracking-[-0.04em] text-red-950 leading-tight">
          S.3C CLASS<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-600 via-orange-500 to-yellow-500">
            EXPERIENCE DAY
          </span>
        </h1>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight text-red-900/60 mb-12">
          Bowling Tournament 2026
        </h2>

        <motion.button
          onClick={onNext}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="group relative flex items-center gap-3 px-10 py-5 bg-gradient-to-br from-red-600 to-orange-500 text-white rounded-full font-black text-xl transition-shadow shadow-xl shadow-red-500/30 hover:shadow-2xl hover:shadow-red-500/40 mb-8"
        >
          Enter the Arena
          <ArrowRight className="group-hover:translate-x-1 transition-transform" strokeWidth={3} />
        </motion.button>
      </motion.div>

      {user && savedRecords.length > 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="z-10 w-full max-w-xl px-4"
        >
          <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4 text-center">Previous Draws</h3>
          <div className="flex flex-col gap-3">
            {savedRecords.map(record => (
              <motion.div 
                key={record.id}
                whileHover={{ scale: 1.02 }}
                onClick={() => loadRecord(record)}
                className="flex flex-row items-center justify-between p-4 bg-white/70 backdrop-blur-lg rounded-2xl border border-gray-200 shadow-sm cursor-pointer hover:shadow-md transition-shadow"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 text-orange-600 rounded-full">
                    <Clock size={20} />
                  </div>
                  <div className="text-left">
                    <div className="font-bold text-gray-800">
                      {new Date(record.date).toLocaleDateString()} {new Date(record.date).toLocaleTimeString()}
                    </div>
                    <div className="text-sm text-gray-500">
                      {record.participants.length} Players • {record.openLanes} Lanes
                    </div>
                  </div>
                </div>
                <button 
                  onClick={(e) => deleteRecord(record.id, e)}
                  className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </motion.div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Portal Link */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-12 z-10"
      >
        <Link 
          to="/s3experienceday"
          className="flex items-center gap-2 text-sm font-semibold text-gray-500 hover:text-red-500 transition-colors"
        >
          <Calendar size={16} />
          Go to S3 Experience Day Portal
        </Link>
      </motion.div>
    </div>
  );
}
