import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Calendar, Clock, Banknote, ArrowRight, ArrowLeft } from 'lucide-react';

interface Props {
  onNext: () => void;
}

function AnimatedCoordinate({ value }: { value: string }) {
  const [display, setDisplay] = useState('');
  
  useEffect(() => {
    let iteration = 0;
    const interval = setInterval(() => {
      setDisplay(value.split('').map((char, index) => {
        if (index < iteration) {
          return char;
        }
        if (char === '.' || char === ',' || char === ' ') return char;
        return Math.floor(Math.random() * 10).toString();
      }).join(''));
      
      if (iteration >= value.length) {
        clearInterval(interval);
      }
      iteration += 1 / 2; 
    }, 40);
    
    return () => clearInterval(interval);
  }, [value]);

  return <span>{display}</span>;
}

export default function InfoView({ onNext }: Props) {
  const [slideIndex, setSlideIndex] = useState(0);

  const nextSlide = () => {
    if (slideIndex < 2) {
      setSlideIndex(slideIndex + 1);
    } else {
      onNext();
    }
  };

  const prevSlide = () => {
    if (slideIndex > 0) {
      setSlideIndex(slideIndex - 1);
    }
  };

  return (
    <div className="relative flex flex-col items-center justify-center min-h-screen bg-[#FDFBF7] p-6">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-[-20%] right-[-10%] w-[50%] h-[50%] rounded-full bg-red-400/20 blur-[120px]" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[50%] h-[50%] rounded-full bg-yellow-400/20 blur-[120px]" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="z-10 w-full max-w-xl bg-white rounded-3xl shadow-xl shadow-red-500/5 border border-red-100 overflow-hidden flex flex-col min-h-[450px]"
      >
        <div className="bg-gradient-to-r from-red-600 to-orange-500 p-8 text-white shrink-0">
          <h2 className="text-3xl font-black mb-2">Event Information</h2>
          <div className="flex gap-2 mt-4">
            {[0, 1, 2].map(i => (
              <div key={i} className={`h-2 flex-1 rounded-full ${i <= slideIndex ? 'bg-white' : 'bg-white/30'}`} />
            ))}
          </div>
        </div>

        <div className="p-8 flex-1 relative flex items-center justify-center">
          <AnimatePresence mode="wait">
            {slideIndex === 0 && (
              <motion.div
                key="slide-0"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="w-full flex flex-col items-center text-center space-y-6"
              >
                <div className="w-24 h-24 bg-red-50 rounded-full text-red-500 flex items-center justify-center">
                  <MapPin size={48} />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-gray-900 mb-2">US Dacos Bowling Centre</h3>
                  <p className="text-xl text-gray-600 font-medium mb-6">荃灣迪高保齡球館</p>
                  <a 
                    href="https://www.google.com/maps/search/?api=1&query=22.373320943900715,114.12354407249177" 
                    target="_blank" 
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 transition-colors rounded-xl text-sm font-mono font-bold text-gray-600 shadow-inner"
                  >
                    <AnimatedCoordinate value="22.373320943900715, 114.12354407249177" />
                  </a>
                </div>
              </motion.div>
            )}

            {slideIndex === 1 && (
              <motion.div
                key="slide-1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="w-full flex flex-col items-center text-center space-y-6"
              >
                <div className="w-24 h-24 bg-orange-50 rounded-full text-orange-500 flex items-center justify-center">
                  <Calendar size={48} />
                </div>
                <div>
                  <h3 className="text-3xl font-black text-gray-900 mb-4">Date & Time</h3>
                  <p className="text-2xl text-red-600 font-black mb-2">3rd July 2026</p>
                  <p className="text-xl text-gray-500 font-medium flex items-center justify-center gap-2">
                    <Clock size={20} /> 10:00 AM - 12:00 PM
                  </p>
                </div>
              </motion.div>
            )}

            {slideIndex === 2 && (
              <motion.div
                key="slide-2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="w-full flex flex-col items-center text-center space-y-6"
              >
                <div className="w-24 h-24 bg-yellow-50 rounded-full text-yellow-600 flex items-center justify-center">
                  <Banknote size={48} />
                </div>
                <div>
                   <h3 className="text-3xl font-black text-gray-900 mb-4">Pricing</h3>
                   <div className="bg-green-50 text-green-700 px-6 py-4 rounded-3xl border border-green-200 inline-block">
                     <p className="text-4xl font-black mb-1">$30 <span className="text-xl font-medium text-green-600/80">/ person</span></p>
                     <p className="text-sm font-bold tracking-widest uppercase">For 2 Hours</p>
                   </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-between shrink-0">
          <button
             onClick={prevSlide}
             className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-opacity ${slideIndex > 0 ? 'text-gray-600 hover:bg-gray-200' : 'opacity-0 pointer-events-none'}`}
          >
            <ArrowLeft size={20} />
            Back
          </button>
          
          <motion.button
            onClick={nextSlide}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`flex items-center gap-3 px-8 py-3 rounded-xl font-bold shadow-md ${slideIndex === 2 ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-red-500/20' : 'bg-white border border-gray-200 text-gray-800'}`}
          >
            {slideIndex === 2 ? 'Tournament Setup' : 'Next'}
            <ArrowRight size={20} strokeWidth={slideIndex === 2 ? 3 : 2} />
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
}
