import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppState } from '../types';
import { ALL_STUDENTS } from '../constants';
import { ArrowRight, Dices, Swords, ArrowLeft, Loader2 } from 'lucide-react';
import { saveRecordToFirebase } from '../lib/records';

interface Props {
  state: AppState;
  updateState: (s: Partial<AppState>) => void;
}

let sharedAudioCtx: AudioContext | null = null;
const getAudioCtx = () => {
  if (!sharedAudioCtx) {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioCtx) {
      sharedAudioCtx = new AudioCtx();
    }
  }
  return sharedAudioCtx;
};

export default function LuckyDrawView({ state, updateState }: Props) {
  const [drawing, setDrawing] = useState(false);
  const [finished, setFinished] = useState(state.drawOrder.length > 0);
  const [saved, setSaved] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<number[]>(
    state.drawOrder.length > 0 ? state.drawOrder : []
  );
  const [remainingPool, setRemainingPool] = useState<number[]>(
    state.drawOrder.length > 0 ? [] : state.settings.participants
  );

  const playPopSound = () => {
    try {
      const ctx = getAudioCtx();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400 + Math.random() * 200, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.1);
      
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
      
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch (e) {
      // Ignore
    }
  };

  const playFanfare = () => {
    try {
      const ctx = getAudioCtx();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'triangle';
      
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.setValueAtTime(554.37, ctx.currentTime + 0.2);
      osc.frequency.setValueAtTime(659.25, ctx.currentTime + 0.4);
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.6);
      
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 1);
      
      osc.start();
      osc.stop(ctx.currentTime + 1);
    } catch(e) {}
  };

  const startDraw = () => {
    // Resume context on user gesture
    getAudioCtx()?.resume();
    
    setDrawing(true);
    setFinished(false);
    
    let currentRemaining = [...state.settings.participants];
    setRemainingPool(currentRemaining);
    let placed: number[] = [];
    setCurrentOrder([]);
    
    // total duration ~ 46 seconds (at least)
    const intervalMs = Math.max(300, Math.floor(46000 / currentRemaining.length));
    
    const interval = setInterval(() => {
      if (currentRemaining.length === 0) {
        clearInterval(interval);
        setDrawing(false);
        setFinished(true);
        updateState({ drawOrder: placed });
        playFanfare();
        return;
      }
      
      const randomIndex = Math.floor(Math.random() * currentRemaining.length);
      const pickedId = currentRemaining[randomIndex];
      currentRemaining.splice(randomIndex, 1);
      
      placed = [...placed, pickedId];
      setCurrentOrder(placed);
      setRemainingPool([...currentRemaining]);
      playPopSound();
    }, intervalMs);
  };

  const proceed = () => {
    updateState({ mode: 'bracket' });
  };

  const totalMatches = state.settings.openLanes;
  const matchGroups: (number | null)[][] = useMemo(() => {
    const grouped: (number | null)[][] = [];
    const baseSize = Math.floor(state.settings.participants.length / totalMatches);
    const extra = state.settings.participants.length % totalMatches;
    
    let currentIndex = 0;
    for (let i = 0; i < totalMatches; i++) {
        const spotsForThisMatch = baseSize + (i < extra ? 1 : 0);
        const matchSlots: (number | null)[] = [];
        for (let j = 0; j < spotsForThisMatch; j++) {
            const index = currentIndex++;
            matchSlots.push(currentOrder[index] !== undefined ? currentOrder[index] : null);
        }
        grouped.push(matchSlots);
    }
    return grouped;
  }, [currentOrder, state.settings.openLanes, state.settings.participants.length]);

  const [isSaving, setIsSaving] = useState(false);

  const saveRecords = async () => {
    try {
      setIsSaving(true);
      await saveRecordToFirebase({
        date: Date.now(),
        drawOrder: [...currentOrder],
        participants: state.settings.participants,
        openLanes: state.settings.openLanes,
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (e: any) {
      console.error('Could not save records', e);
      alert(e.message || "Failed to save record. Try returning to the Landing page to log in.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex flex-col items-center min-h-screen py-16 px-4 bg-[#FDFBF7] text-gray-900 relative">
      <div className="absolute top-0 right-0 w-[50%] h-[50%] rounded-full bg-gradient-to-br from-yellow-300/30 to-red-500/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-[-10%] w-[40%] h-[40%] rounded-full bg-gradient-to-tr from-red-600/10 to-orange-400/20 blur-[100px] pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="z-10 flex flex-col items-center mb-12"
      >
        <div className="p-4 rounded-full bg-white border border-red-100 shadow-sm mb-6">
          <Dices className="text-red-600" size={32} />
        </div>
        <h1 className="text-4xl font-black tracking-tight mb-2 text-red-950">Order Draw</h1>
        <p className="text-red-900/60 font-medium tracking-wide border-b border-red-200 pb-1">Randomising the bowling lineup</p>
      </motion.div>

      <div className="z-10 w-full max-w-7xl flex flex-col items-center">
        {!finished && !drawing && (
          <div className="flex items-center gap-4 mb-12">
            <button 
              onClick={() => updateState({ mode: 'settings' })}
              className="flex items-center gap-2 px-6 py-5 rounded-full font-bold text-gray-500 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft size={20} />
              Back
            </button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={startDraw}
              className="px-12 py-5 bg-gradient-to-r from-red-600 to-orange-500 text-white rounded-full font-bold text-xl shadow-xl shadow-red-500/25"
            >
              Start Lucky Draw
            </motion.button>
          </div>
        )}

        {finished && (
          <div className="flex items-center gap-4 mb-12">
            <button 
              onClick={() => updateState({ mode: 'settings' })}
              className="flex items-center gap-2 px-6 py-4 rounded-full font-bold text-gray-500 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft size={20} />
              Back
            </button>
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={proceed}
              className="flex items-center gap-3 px-10 py-4 bg-white text-red-700 border-2 border-red-600 rounded-full font-bold text-lg hover:bg-red-50 transition-colors shadow-lg shadow-red-500/10"
            >
              Go to Tournament Bracket
              <ArrowRight size={20} />
            </motion.button>
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={!(saved || isSaving) ? { scale: 1.05 } : {}}
              whileTap={!(saved || isSaving) ? { scale: 0.95 } : {}}
              onClick={saveRecords}
              disabled={saved || isSaving}
              className={`flex items-center gap-2 px-6 py-4 rounded-full font-bold text-lg transition-colors shadow-lg shadow-gray-900/10 ${
                saved ? 'bg-green-500 hover:bg-green-600 text-white' : 'bg-gray-900 text-white hover:bg-gray-800'
              }`}
            >
              {isSaving ? (
                <><Loader2 size={20} className="animate-spin" /> Saving...</>
              ) : saved ? (
                "Saved!"
              ) : (
                "Save Records"
              )}
            </motion.button>
          </div>
        )}

        {/* The Machine */}
        {(remainingPool.length > 0 || drawing) && !finished && (
          <div className="w-full max-w-5xl bg-white/40 backdrop-blur-3xl rounded-[3rem] border-4 border-orange-300 p-8 shadow-[0_0_80px_-15px_rgba(251,146,60,0.4)] mb-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-yellow-400/10 rounded-[3rem]" />
            <h2 className="text-center font-black text-orange-600 mb-6 uppercase tracking-widest text-sm relative z-10 flex items-center justify-center gap-2">
              {drawing && <span className="w-3 h-3 rounded-full bg-red-500 animate-pulse"></span>}
              The Machine
            </h2>
            <div className="flex flex-wrap justify-center content-center gap-3 relative z-10 min-h-[160px]">
              <AnimatePresence>
                {remainingPool.map(id => {
                  const student = ALL_STUDENTS.find(s => s.id === id);
                  return (
                    <motion.div
                      key={id}
                      layoutId={`student-${id}`}
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ 
                        scale: 1, 
                        opacity: 1, 
                        x: drawing ? [0, Math.random() * 20 - 10, Math.random() * -20 + 10, 0] : 0, 
                        y: drawing ? [0, Math.random() * -30, Math.random() * 10, 0] : 0,
                        rotate: drawing ? [0, Math.random() * 360, 0] : 0
                      }}
                      transition={{ 
                        x: drawing ? { repeat: Infinity, duration: 0.15 + Math.random() * 0.2, ease: "linear" } : { duration: 0.3 },
                        y: drawing ? { repeat: Infinity, duration: 0.15 + Math.random() * 0.2, ease: "linear" } : { duration: 0.3 },
                        rotate: drawing ? { repeat: Infinity, duration: 0.5 + Math.random(), ease: "linear" } : { duration: 0.3 }
                      }}
                      exit={{ scale: 0, opacity: 0 }}
                      className="w-14 h-14 rounded-full border-4 border-orange-500 bg-gradient-to-br from-yellow-300 to-orange-500 shadow-xl flex items-center justify-center font-black text-white text-xl z-50"
                    >
                      {student?.no}
                    </motion.div>
                  )
                })}
              </AnimatePresence>
            </div>
          </div>
        )}

        <div className="w-full relative min-h-[400px]">
          <div className="flex flex-wrap justify-center gap-6">
            <AnimatePresence>
              {matchGroups.map((matchGroup, mIndex) => (
                <motion.div
                  key={`match-${mIndex}`}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: mIndex * 0.05 }}
                  className={`bg-white rounded-3xl border flex flex-col w-72 overflow-hidden transition-all duration-300 ${
                    finished ? 'border-red-200 shadow-lg shadow-red-500/5' : 'border-gray-200 shadow-sm'
                  }`}
                >
                  <div className={`px-4 py-2 border-b text-xs font-bold flex justify-between items-center transition-colors ${
                    finished ? 'bg-red-50 text-red-800 border-red-100' : 'bg-gray-50 text-gray-500 border-gray-100'
                  }`}>
                    <span className="flex items-center gap-1.5"><Swords size={14}/> Match {mIndex + 1}</span>
                  </div>
                  
                  <div className="p-3 space-y-2 flex-1 relative flex flex-col min-h-[140px]">
                      {matchGroup.map((id, sIndex) => {
                        if (id === null) {
                           return (
                             <div key={`empty-${sIndex}`} className="flex items-center p-2 rounded-xl border border-dashed border-gray-300 bg-gray-50/50">
                               <div className="w-8 h-8 mr-3 flex items-center justify-center rounded-xl bg-gray-100 font-bold text-gray-300 text-xs text-center border border-gray-200 border-dashed">?</div>
                               <div className="flex-1 text-gray-400 font-medium text-sm">Drawing...</div>
                             </div>
                           );
                        }
                        
                        const student = ALL_STUDENTS.find(s => s.id === id)!;
                        return (
                          <motion.div
                            initial={{ opacity: 0, x: -20, scale: 0.8 }}
                            animate={{ opacity: 1, x: 0, scale: 1 }}
                            layoutId={`student-${student.id}`}
                            key={student.id}
                            transition={{ type: "spring", stiffness: 300, damping: 25 }}
                            className={`flex items-center p-2 rounded-xl transition-colors border z-10 ${
                              finished 
                                ? 'bg-white border-red-100 shadow-sm hover:border-red-300' 
                                : 'bg-yellow-50 border-yellow-200 shadow-sm'
                            }`}
                          >
                            <div className={`w-8 h-8 mr-3 flex items-center justify-center rounded-xl font-black text-xs transition-colors ${
                              finished ? 'bg-gradient-to-br from-red-500 to-orange-500 text-white shadow-md' : 'bg-white text-gray-500 border border-gray-200'
                            }`}>
                              {student.no}
                            </div>
                            <div className="flex-1 overflow-hidden font-bold text-gray-800 truncate text-sm">
                              {student.name}
                            </div>
                          </motion.div>
                        );
                      })}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
}
