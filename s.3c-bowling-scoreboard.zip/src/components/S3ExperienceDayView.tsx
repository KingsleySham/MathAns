import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Sparkles, Calendar } from 'lucide-react';

export default function S3ExperienceDayView() {
  return (
    <div className="min-h-screen bg-[#FDFBF7] text-gray-900 font-sans flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Version Corner */}
      <div className="fixed top-2 left-2 z-50 text-xs font-mono text-red-900/40 pointer-events-none">
        v1.1.0
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-3xl w-full text-center z-10"
      >
        <div className="inline-flex items-center justify-center p-4 bg-orange-100 rounded-full mb-8 text-orange-600 shadow-sm">
          <Calendar size={32} />
        </div>

        <h1 className="text-5xl md:text-7xl font-black text-gray-900 mb-6 tracking-tight leading-none">
          S3 Experience Day
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-600 font-medium mb-12 max-w-2xl mx-auto leading-relaxed">
          Welcome to the dedicated portal for the S3 Experience Day. More content and features will be merged here soon.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <button className="flex items-center gap-2 px-8 py-4 bg-gray-900 text-white rounded-full font-bold text-lg hover:bg-gray-800 transition-colors shadow-lg">
              <Sparkles size={20} />
              Register Interest
            </button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Link to="/" className="flex items-center gap-2 px-8 py-4 bg-white text-gray-800 rounded-full font-bold text-lg hover:bg-gray-50 transition-colors shadow-sm border border-gray-200">
              <ArrowLeft size={20} />
              Back to Main App
            </Link>
          </motion.div>
        </div>
      </motion.div>

      {/* Decorative background elements */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-orange-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob pointer-events-none"></div>
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-red-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000 pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-1/3 w-96 h-96 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000 pointer-events-none"></div>
    </div>
  );
}
