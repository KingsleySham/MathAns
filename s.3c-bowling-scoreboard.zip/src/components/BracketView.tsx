import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppState, Match, Round } from '../types';
import { ALL_STUDENTS } from '../constants';
import { Trophy, Check, Swords, ArrowRight, ArrowLeft, Download, Upload, X } from 'lucide-react';

interface Props {
  state: AppState;
  updateScore: (matchId: string, studentId: number, score: number) => void;
  toggleMatchFinished: (matchId: string, finished: boolean) => void;
  updateState: (s: Partial<AppState>) => void;
  generateNextRound: () => void;
}

export default function BracketView({ state, updateScore, toggleMatchFinished, updateState, generateNextRound }: Props) {
  const [editingCell, setEditingCell] = useState<{ matchId: string; studentId: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedPlayer, setSelectedPlayer] = useState<number | null>(null);

  const exportCSV = () => {
    const lines = ["Round,MatchID,MatchFinished,StudentID,Score"];
    state.rounds.forEach((round, rIndex) => {
      round.matches.forEach(match => {
        match.participants.forEach(pid => {
          const score = match.scores[pid] !== undefined ? match.scores[pid] : '';
          lines.push(`${rIndex + 1},${match.id},${match.finished},${pid},${score}`);
        });
      });
    });
    
    const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", "bowling_bracket.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const importCSV = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const lines = text.split('\n').map(l => l.trim()).filter(l => l);
      if (lines.length < 2) return; 

      const parsedRounds: Round[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].split(',');
        if (parts.length >= 5) {
          const roundNum = parseInt(parts[0], 10);
          const matchId = parts[1];
          const finished = parts[2] === 'true';
          const studentId = parseInt(parts[3], 10);
          const scoreStr = parts[4];
          
          // Ignore invalid rows
          if (isNaN(roundNum) || isNaN(studentId)) continue;
          
          const rIndex = roundNum - 1;
          
          // Ensure round array exists up to current index
          while (parsedRounds.length <= rIndex) {
            parsedRounds.push({ matches: [] });
          }
          
          let match = parsedRounds[rIndex].matches.find(m => m.id === matchId);
          if (!match) {
            match = {
              id: matchId,
              participants: [],
              scores: {},
              finished: finished
            };
            parsedRounds[rIndex].matches.push(match);
          }
          
          if (!match.participants.includes(studentId)) {
            match.participants.push(studentId);
          }
          
          if (scoreStr !== '') {
            match.scores[studentId] = parseInt(scoreStr, 10);
          }
        }
      }
      
      updateState({ rounds: parsedRounds });
    };
    reader.readAsText(file);
    event.target.value = ''; // Reset input
  };

  const handleScoreChange = (matchId: string, studentId: number, value: string) => {
    const num = parseInt(value, 10);
    if (!isNaN(num)) {
      updateScore(matchId, studentId, num);
    } else if (value === "") {
      updateScore(matchId, studentId, 0);
    }
  };

  const isRoundComplete = (roundIndex: number) => {
    if (state.rounds.length <= roundIndex) return false;
    return state.rounds[roundIndex].matches.every(m => m.finished);
  };

  const getWinner = () => {
    if (state.rounds.length === 0) return null;
    const lastRound = state.rounds[state.rounds.length - 1];
    if (lastRound.matches.length === 1 && lastRound.matches[0].finished) {
      const match = lastRound.matches[0];
      const sorted = [...match.participants].sort((a, b) => (match.scores[b] || 0) - (match.scores[a] || 0));
      return ALL_STUDENTS.find(s => s.id === sorted[0]);
    }
    return null;
  };

  const winner = getWinner();

  let playerStats = null;
  if (selectedPlayer) {
    const student = ALL_STUDENTS.find(s => s.id === selectedPlayer);
    const playerScores: number[] = [];
    state.rounds.forEach(round => {
      round.matches.forEach(match => {
        if (match.participants.includes(selectedPlayer)) {
           if (match.scores[selectedPlayer] !== undefined && match.finished) {
             playerScores.push(match.scores[selectedPlayer]);
           }
        }
      })
    });
    const matchesPlayed = playerScores.length;
    const totalScore = playerScores.reduce((a, b) => a + b, 0);
    const averageScore = matchesPlayed > 0 ? (totalScore / matchesPlayed).toFixed(1) : '0.0';
    const highScore = matchesPlayed > 0 ? Math.max(...playerScores) : 0;
    
    // Derived mock stats based on score
    const totalStrikes = playerScores.reduce((acc, score) => acc + Math.floor(score / 20), 0);
    const totalSpares = playerScores.reduce((acc, score) => acc + Math.floor((score % 20) / 10), 0);
    const spareRate = matchesPlayed > 0 ? Math.min(100, Math.floor((totalSpares / (matchesPlayed * 10)) * 100)) + '%' : '0%';

    if (student) {
      playerStats = {
        ...student,
        matchesPlayed,
        totalScore,
        averageScore,
        highScore,
        totalStrikes,
        spareRate
      };
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FDFBF7] p-6 md:p-12 relative overflow-auto">
      <AnimatePresence>
        {selectedPlayer && playerStats && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedPlayer(null)}
              className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white shadow-2xl z-50 p-6 overflow-y-auto border-l border-red-100"
            >
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-red-100">
                <h2 className="text-2xl font-black text-red-950 flex items-center gap-3">
                  <Trophy size={24} className="text-orange-500" />
                  Player Stats
                </h2>
                <button onClick={() => setSelectedPlayer(null)} className="p-2 hover:bg-red-50 text-red-900 rounded-full transition-colors cursor-pointer">
                  <X size={24} />
                </button>
              </div>
              
              <div className="flex items-center gap-5 mb-8">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 text-white flex items-center justify-center text-4xl font-black shadow-lg shadow-red-500/20">
                  {playerStats.no}
                </div>
                <div>
                  <div className="text-2xl font-black text-gray-900 leading-tight">{playerStats.name}</div>
                  <div className="text-base font-bold text-gray-500">{playerStats.zhName}</div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-red-50 p-5 rounded-3xl border border-red-100 shadow-sm relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/40 blur-2xl rounded-full" />
                  <div className="text-xs font-bold text-red-800/60 uppercase tracking-widest mb-1 relative z-10">Average Score</div>
                  <div className="text-5xl font-black text-red-950 relative z-10">{playerStats.averageScore}</div>
                </div>
                <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">High Score</div>
                  <div className="text-3xl font-black text-gray-900">{playerStats.highScore}</div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100 shadow-sm">
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Strikes</div>
                    <div className="text-2xl font-black text-gray-900">{playerStats.totalStrikes}</div>
                  </div>
                  <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100 shadow-sm">
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Spares</div>
                    <div className="text-2xl font-black text-gray-900">{playerStats.spareRate}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100 shadow-sm">
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Matches</div>
                    <div className="text-2xl font-black text-gray-900">{playerStats.matchesPlayed}</div>
                  </div>
                  <div className="bg-gray-50 p-5 rounded-3xl border border-gray-100 shadow-sm">
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-1">Total Pts</div>
                    <div className="text-2xl font-black text-gray-900">{playerStats.totalScore}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="fixed top-0 right-[-10%] w-[60%] h-[60%] rounded-full bg-gradient-to-br from-red-600/5 to-orange-400/10 blur-[150px] pointer-events-none" />

      <header className="z-10 flex flex-col md:flex-row md:items-center justify-between mb-8 gap-6 shrink-0">
        <div>
          <button 
            onClick={() => updateState({ mode: 'lucky_draw' })}
            className="flex items-center gap-2 text-red-900/50 hover:text-red-600 transition-colors mb-4 text-sm font-bold"
          >
            <ArrowLeft size={16} />
            Back to Draw
          </button>
          <h1 className="text-4xl font-black tracking-tight text-red-950 flex items-center gap-4">
            <Swords className="text-red-500" size={36} />
            Tournament Bracket
          </h1>
          <p className="text-red-900/60 mt-2 font-medium">S.3C Class Experience Day - Bowling Competition</p>
        </div>

        <div className="flex flex-col items-end gap-3">
          <div className="flex gap-4">
            <div className="px-6 py-3 rounded-2xl bg-white border border-red-200 shadow-sm text-center">
              <div className="text-xs text-blue-500 font-bold uppercase tracking-wider mb-1">Lanes (Matches)</div>
              <div className="text-2xl font-black text-blue-950">{state.settings.openLanes || 4}</div>
            </div>
            <div className="px-6 py-3 rounded-2xl bg-white border border-red-200 shadow-sm text-center">
              <div className="text-xs text-orange-400 font-bold uppercase tracking-wider mb-1">Advance</div>
              <div className="text-2xl font-black text-red-950">Top {state.settings.advanceCount}</div>
            </div>
          </div>
          <div className="flex gap-2">
            <input 
              type="file" 
              accept=".csv" 
              onChange={importCSV} 
              className="hidden" 
              ref={fileInputRef} 
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 text-xs font-bold text-red-800 bg-red-50 border border-red-100 px-3 py-2 rounded-lg hover:bg-red-100 transition-colors shadow-sm"
            >
              <Upload size={14} /> Import CSV
            </button>
            <button 
              onClick={exportCSV}
              className="flex items-center gap-2 text-xs font-bold text-red-800 bg-red-50 border border-red-100 px-3 py-2 rounded-lg hover:bg-red-100 transition-colors shadow-sm"
            >
              <Download size={14} /> Export CSV
            </button>
          </div>
        </div>
      </header>

      {state.rounds.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="p-12 rounded-3xl bg-white border border-red-200 shadow-xl flex flex-col items-center"
          >
            <Trophy size={64} className="text-yellow-500 mb-6" />
            <h2 className="text-2xl font-black text-red-950 mb-2">Ready to Bowl?</h2>
            <p className="text-red-900/60 mb-8 font-medium">Generates the initial bracket matches.</p>
            <button
              onClick={generateNextRound}
              className="px-10 py-4 bg-gradient-to-r from-red-600 to-orange-500 text-white rounded-full font-bold text-xl shadow-lg shadow-red-500/30 hover:scale-105 transition-transform"
            >
              Start Tournament
            </button>
          </motion.div>
        </div>
      ) : (
        <div className="flex gap-12 overflow-x-auto min-h-0 pb-12 items-start shrink-0">
          {state.rounds.map((round, rIndex) => (
            <div key={rIndex} className="flex flex-col gap-6 shrink-0 w-80">
              <div className="flex items-center justify-between bg-white px-5 py-3 rounded-2xl shadow-sm border border-red-100">
                <h3 className="font-black text-lg text-red-950">{round.title || `Round ${rIndex + 1}`}</h3>
                {isRoundComplete(rIndex) && rIndex === state.rounds.length - 1 && !winner && (
                  <button 
                    onClick={generateNextRound}
                    className="flex items-center gap-1 text-sm bg-gradient-to-r from-red-600 to-orange-500 text-white px-3 py-1.5 rounded-lg font-bold shadow-md hover:shadow-lg transition-shadow"
                  >
                    Next Round <ArrowRight size={14} strokeWidth={3} />
                  </button>
                )}
              </div>

              {round.matches.map((match, mIndex) => {
                const sortedParticipants = [...match.participants].sort((a, b) => (match.scores[b] || 0) - (match.scores[a] || 0));
                
                return (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: mIndex * 0.05 }}
                    key={match.id} 
                    className={`bg-white rounded-3xl border ${match.finished ? 'border-green-200 bg-green-50/30' : 'border-red-200'} shadow-sm overflow-hidden`}
                  >
                    <div className={`px-4 py-2 border-b text-xs font-bold flex justify-between items-center ${match.finished ? 'bg-green-100 text-green-800 border-green-200' : 'bg-red-50 text-red-800 border-red-100'}`}>
                      <span>Match {mIndex + 1}</span>
                      {match.finished && <span className="flex items-center gap-1"><Check size={12}/> Finished</span>}
                    </div>
                    
                    <div className="p-2 space-y-1">
                      {match.participants.map((pid) => {
                        const student = ALL_STUDENTS.find(s => s.id === pid)!;
                        const score = match.scores[pid] || 0;
                        const isEditing = editingCell?.matchId === match.id && editingCell?.studentId === pid;
                        
                        let isAdvancing = false;
                        if (match.finished) {
                           const rank = sortedParticipants.indexOf(pid);
                           isAdvancing = rank < state.settings.advanceCount;
                        }

                        return (
                          <div key={pid} className={`flex items-center justify-between p-2 rounded-xl transition-colors ${isAdvancing ? 'bg-green-100/50' : 'hover:bg-gray-50'}`}>
                            <div className="flex-1 min-w-0 pr-2">
                              <div 
                                onClick={() => setSelectedPlayer(pid)}
                                className="font-bold text-sm text-gray-900 truncate cursor-pointer hover:text-red-600 transition-colors select-none"
                              >
                                <span className="text-gray-400 font-mono text-xs mr-2">{student.no}</span>
                                {student.name}
                              </div>
                            </div>
                            
                            <div className="shrink-0 flex items-center">
                              {match.finished && isAdvancing && (
                                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className="mr-2 text-green-600">
                                  <Trophy size={14} />
                                </motion.div>
                              )}
                              
                              {match.finished ? (
                                <div className="w-12 text-right font-black font-mono text-lg text-gray-900">
                                  {score}
                                </div>
                              ) : (
                                isEditing ? (
                                  <input
                                    autoFocus
                                    type="number"
                                    className="w-16 h-8 bg-white border-2 border-red-400 rounded-lg text-center font-bold text-gray-900 shadow-sm outline-none"
                                    value={score || ''}
                                    onChange={(e) => handleScoreChange(match.id, pid, e.target.value)}
                                    onBlur={() => setEditingCell(null)}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') setEditingCell(null);
                                    }}
                                  />
                                ) : (
                                  <div 
                                    onClick={() => setEditingCell({ matchId: match.id, studentId: pid })}
                                    className="w-16 h-8 flex items-center justify-center rounded-lg bg-gray-50 border border-gray-200 text-gray-600 cursor-pointer font-bold font-mono hover:bg-white hover:border-red-300 transition-colors"
                                  >
                                    {score > 0 ? score : '-'}
                                  </div>
                                )
                              )}
                            </div>
                          </div>
                        )
                      })}
                    </div>
                    
                    <div className="p-3 border-t border-gray-100 bg-gray-50/50 flex justify-center">
                      <button
                        onClick={() => toggleMatchFinished(match.id, !match.finished)}
                        className={`text-xs font-bold px-4 py-2 rounded-lg transition-colors ${
                          match.finished 
                            ? 'text-gray-500 hover:bg-gray-200' 
                            : 'bg-red-100 text-red-700 hover:bg-red-200'
                        }`}
                      >
                        {match.finished ? 'Reopen Match' : 'Finalise Scores'}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ))}

          {/* Winner Column */}
          <AnimatePresence>
            {winner && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, x: -50 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                className="flex flex-col gap-6 shrink-0 w-80 items-center justify-center min-h-[400px]"
              >
                 <div className="p-8 rounded-3xl bg-gradient-to-br from-yellow-300 to-yellow-500 shadow-[0_20px_50px_rgba(234,179,8,0.3)] flex flex-col items-center text-center relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/20 rounded-full blur-2xl pointer-events-none" />
                    <Trophy size={80} className="text-yellow-100 drop-shadow-md mb-6" strokeWidth={1.5} />
                    <h3 className="text-sm font-black uppercase tracking-widest text-yellow-950/50 mb-2">Grand Champion</h3>
                    <h2 className="text-3xl font-black text-yellow-950 leading-tight mb-2">{winner.name}</h2>
                    <p className="font-medium text-yellow-900 border border-yellow-600/30 rounded-lg px-3 py-1 bg-yellow-400/20">{winner.zhName}</p>
                 </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
