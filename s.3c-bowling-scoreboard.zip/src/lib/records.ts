import { db, auth } from './firebase';
import { collection, doc, setDoc, getDocs, deleteDoc, query, orderBy, onSnapshot } from 'firebase/firestore';

export interface SavedRecord {
  id: string;
  date: number;
  drawOrder: number[];
  participants: number[];
  openLanes: number;
  userId: string;
}

export const saveRecordToFirebase = async (record: Omit<SavedRecord, 'id' | 'userId'>) => {
  if (!auth.currentUser) throw new Error("Must be logged in to save records");
  const uid = auth.currentUser.uid;
  const newId = Date.now().toString();
  const docRef = doc(collection(db, 'users', uid, 'drawRecords'), newId);
  await setDoc(docRef, { ...record, id: newId, userId: uid });
};

export const deleteRecordFromFirebase = async (recordId: string) => {
  if (!auth.currentUser) return;
  const uid = auth.currentUser.uid;
  await deleteDoc(doc(db, 'users', uid, 'drawRecords', recordId));
};

export const subscribeToRecords = (callback: (records: SavedRecord[]) => void) => {
  if (!auth.currentUser) {
    callback([]);
    return () => {};
  }
  const uid = auth.currentUser.uid;
  const q = query(collection(db, 'users', uid, 'drawRecords'), orderBy('date', 'desc'));
  
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => doc.data() as SavedRecord));
  }, (error) => {
    console.error('Firebase snapshot error:', error);
  });
};
