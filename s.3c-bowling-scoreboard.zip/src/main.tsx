import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import App from './App.tsx';
import S3ExperienceDayView from './components/S3ExperienceDayView.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<App />} />
        <Route path="/s3experienceday" element={<S3ExperienceDayView />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>,
);
