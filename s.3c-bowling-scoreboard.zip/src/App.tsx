import { useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { AppState } from './types';
import LandingView from './components/LandingView';
import InfoView from './components/InfoView';
import SettingsView from './components/SettingsView';
import LuckyDrawView from './components/LuckyDrawView';
import BracketView from './components/BracketView';

let socket: Socket;

export default function App() {
  const [state, setState] = useState<AppState | null>(null);

  useEffect(() => {
    socket = io();

    socket.on('stateUpdated', (newState: AppState) => {
      setState(newState);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#FDFBF7] text-red-900">
        <div className="animate-pulse font-bold text-xl">Loading Application State...</div>
      </div>
    );
  }

  const updateState = (partialState: Partial<AppState>) => {
    socket.emit('updateState', partialState);
  };

  const updateScore = (matchId: string, studentId: number, score: number) => {
    socket.emit('updateScore', { matchId, studentId, score });
  };

  const toggleMatchFinished = (matchId: string, finished: boolean) => {
    socket.emit('toggleMatchFinished', { matchId, finished });
  };

  const generateNextRound = () => {
    socket.emit('generateNextRound');
  };

  const currentMode = state.mode;

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-gray-900 font-sans overflow-x-hidden">
      {/* Version Corner */}
      <div className="fixed top-2 left-2 z-50 text-xs font-mono text-red-900/40 pointer-events-none">
        v1.1.0
      </div>

      {currentMode === 'landing' && <LandingView onNext={() => updateState({ mode: 'info' })} updateState={updateState} />}
      {currentMode === 'info' && <InfoView onNext={() => updateState({ mode: 'settings' })} />}
      {currentMode === 'settings' && <SettingsView state={state} updateState={updateState} />}
      {currentMode === 'lucky_draw' && <LuckyDrawView state={state} updateState={updateState} />}
      {currentMode === 'bracket' && (
        <BracketView 
          state={state} 
          updateScore={updateScore} 
          updateState={updateState} 
          toggleMatchFinished={toggleMatchFinished}
          generateNextRound={generateNextRound}
        />
      )}
    </div>
  );
}
