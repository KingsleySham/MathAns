export interface Student {
  id: number;
  no: number | string;
  name: string;
  zhName: string;
}

export type ViewMode = 'landing' | 'info' | 'settings' | 'lucky_draw' | 'bracket';

export interface Match {
  id: string;
  participants: number[]; // student IDs
  scores: Record<number, number>; // studentId -> score
  finished: boolean;
}

export interface Round {
  matches: Match[];
  title?: string;
}

export interface AppState {
  mode: ViewMode;
  settings: {
    advanceCount: number; // e.g., top 1 advances
    openLanes: number;
    participants: number[]; // Array of student IDs
  };
  drawOrder: number[]; // Array of student IDs in drawn order
  rounds: Round[]; // Array of rounds containing matches
  lastUpdated: number;
}

